import { HlsDownloader } from "./hls/downloader";
import { HlsRemuxer } from "./hls/remuxer";
import { HlsResolver, looksLikeHlsUrl } from "./hls/resolver";
import { parseVideoDimensions } from "./media/video-metadata";
import { resolveTwitterMediumMedia } from "./social";
import { MediaFingerprintAccumulator } from "./services/media-fingerprint";
import { fetchPublic, getBaseContentType, getFileExtension } from "./lib/http";
import type {
  MediaType,
  PreparedMedia,
  RelayInput,
  ResolvedDirectFile,
} from "./types";

const TELEGRAM_REMOTE_URL_LIMIT = 20_000_000;
const MEDIUM_QUALITY_FALLBACK_TRIGGER_BYTES = 50_000_000;
const DEFAULT_MAX_MEDIA_BYTES = 49_000_000;
const HARD_MAX_MEDIA_BYTES = 49_000_000;
const DEFAULT_HLS_MAX_MEDIA_BYTES = 16_000_000;
const HARD_HLS_MAX_MEDIA_BYTES = 24_000_000;

const VIDEO_EXTENSIONS = new Set(["mp4", "m4v", "mov", "webm"]);
const PHOTO_EXTENSIONS = new Set(["jpg", "jpeg", "png", "webp", "avif", "gif"]);
const AUDIO_EXTENSIONS = new Set([
  "mp3",
  "m4a",
  "aac",
  "ogg",
  "oga",
  "wav",
  "flac",
]);

export interface PrepareMediaOptions {
  maxMediaBytes?: number;
  concurrency?: number;
  hlsMaxMediaBytes?: number;
  signal?: AbortSignal;
  /** Force a Worker-owned file so it can be attached to a Telegram album. */
  forceUpload?: boolean;
  /** Optional Twirrl token used only by the oversized X medium-quality fallback. */
  twirrlVersionToken?: string;
}

export async function prepareMedia(
  input: RelayInput,
  options: PrepareMediaOptions = {},
): Promise<PreparedMedia> {
  const maxMediaBytes = clampMaxMediaBytes(options.maxMediaBytes);
  const hlsMaxMediaBytes = clampHlsMaxMediaBytes(options.hlsMaxMediaBytes);
  const resolver = new HlsResolver({
    maxDepth: 8,
    maxPlaylistBytes: 2 * 1024 * 1024,
    headers: input.mediaHeaders,
    preferSelfContained: true,
  });
  // URLs with a known media type cannot be HLS playlists. Skip the HEAD probe
  // entirely for those inputs. The previous implementation paid one network RTT
  // just to rediscover information already encoded in the URL.
  const probe = shouldSkipMediaProbe(input.mediaUrl.href)
    ? {
        url: input.mediaUrl.href,
        contentType: inferContentTypeFromUrl(input.mediaUrl.href),
        contentLength: null,
        isPlaylist: false,
      }
    : looksLikeHlsUrl(input.mediaUrl)
      ? {
          url: input.mediaUrl.href,
          contentType: "application/vnd.apple.mpegurl",
          contentLength: null,
          isPlaylist: true,
        }
      : await resolver.probe(input.mediaUrl, {
          headers: input.mediaHeaders,
          signal: options.signal,
        });

  if (!probe.isPlaylist && !looksLikeHlsUrl(input.mediaUrl)) {
    const direct: ResolvedDirectFile = {
      type: "file",
      url: probe.url,
      contentType: probe.contentType || inferContentTypeFromUrl(probe.url),
      contentLength: probe.contentLength,
      selectedBitrate: null,
      selectedResolution: null,
      playlistDepth: 0,
      videoMetadata: null,
    };
    const inferredMediaType =
      input.mediaType || inferTelegramMediaType(direct.url, direct.contentType);
    const isVideo = inferredMediaType === "video";

    if (isVideo && direct.contentLength == null) {
      const rangedLength = await probeContentLengthByRange(
        direct.url,
        input.mediaHeaders,
        options.signal,
      );
      if (rangedLength != null) direct.contentLength = rangedLength;
    }

    if (
      !options.forceUpload &&
      !isVideo &&
      (direct.contentLength == null ||
        direct.contentLength <= TELEGRAM_REMOTE_URL_LIMIT)
    ) {
      return direct;
    }

    if (direct.contentLength != null && direct.contentLength > maxMediaBytes) {
      const mediumFallback = await tryTwitterMediumQualityFallback(
        input,
        direct,
        maxMediaBytes,
        options.signal,
        options.twirrlVersionToken,
      );

      if (mediumFallback) {
        return mediumFallback;
      }

      throw new Error(
        `Direct media is ${direct.contentLength} bytes, above the configured upload limit of ${maxMediaBytes} bytes`,
      );
    }

    const downloadedDirect = await downloadDirectFile(
      direct.url,
      input.mediaHeaders,
      maxMediaBytes,
      options.signal,
    );
    const bytes = downloadedDirect.bytes;
    const mediaType =
      input.mediaType || inferTelegramMediaType(direct.url, direct.contentType);
    const videoMetadata =
      mediaType === "video"
        ? parseVideoDimensions(bytes, direct.contentType)
        : null;

    if (mediaType === "video" && !videoMetadata) {
      throw new Error(
        "Unable to determine the real video dimensions. Refusing to send the video without width/height metadata to prevent Telegram aspect-ratio distortion.",
      );
    }

    return {
      type: "upload",
      bytes,
      filename: filenameFromUrl(direct.url),
      contentType: direct.contentType || "application/octet-stream",
      mediaType,
      selectedBitrate: null,
      selectedResolution: null,
      playlistDepth: 0,
      videoMetadata,
      sourceUrl: direct.url,
      hls: false,
      segmentCount: 1,
      encrypted: false,
      remuxed: false,
      mediaSha256: downloadedDirect.contentIdentity.sha256,
      mediaFingerprint: downloadedDirect.contentIdentity.fingerprint,
      mediaFingerprintVersion: downloadedDirect.contentIdentity.fingerprintVersion,
      mediaByteLength: downloadedDirect.contentIdentity.byteLength,
    };
  }

  const resolved = await resolver.resolve(probe.url || input.mediaUrl.href, {
    headers: input.mediaHeaders,
    signal: options.signal,
  });
  const downloader = new HlsDownloader({
    headers: input.mediaHeaders,
    concurrency: options.concurrency,
    maxMediaBytes: hlsMaxMediaBytes,
  });
  const downloaded = await downloader.download(resolved, {
    signal: options.signal,
  });
  const remuxer = new HlsRemuxer();
  const baseName = baseNameFromUrl(input.sourceUrl || input.mediaUrl.href);
  const remuxed = remuxer.remux(downloaded, baseName);

  if (remuxed.bytes.byteLength > hlsMaxMediaBytes) {
    throw new Error(
      `Remuxed HLS output is ${remuxed.bytes.byteLength} bytes, above the configured in-memory HLS limit of ${hlsMaxMediaBytes} bytes`,
    );
  }

  const variant = resolved.selectedVariant;
  const parsedVideoMetadata = parseVideoDimensions(remuxed.bytes, remuxed.contentType);
  const videoMetadata =
    parsedVideoMetadata ||
    (variant?.resolution
      ? {
          width: variant.resolution.width,
          height: variant.resolution.height,
          durationSeconds: null,
          rotation: 0 as const,
        }
      : null);

  const preparedMediaType = input.mediaType || remuxed.mediaType;
  if (preparedMediaType === "video" && !videoMetadata) {
    throw new Error(
      "Unable to determine the real HLS video dimensions. Refusing to send the video without width/height metadata to prevent Telegram aspect-ratio distortion.",
    );
  }

  const contentIdentity = new MediaFingerprintAccumulator().update(remuxed.bytes).digest();

  return {
    type: "upload",
    bytes: remuxed.bytes,
    filename: remuxed.filename,
    contentType: remuxed.contentType,
    mediaType: preparedMediaType,
    selectedBitrate:
      variant?.averageBandwidth ||
      variant?.bandwidth ||
      null,
    selectedResolution: variant?.resolution?.label || null,
    playlistDepth: Math.max(0, resolved.chain.length - 1),
    videoMetadata,
    sourceUrl: resolved.mediaPlaylist.url,
    hls: true,
    segmentCount:
      downloaded.video.segmentCount +
      (downloaded.audio?.segmentCount || 0),
    encrypted:
      downloaded.video.encrypted ||
      Boolean(downloaded.audio?.encrypted),
    remuxed: remuxed.remuxed,
    mediaSha256: contentIdentity.sha256,
    mediaFingerprint: contentIdentity.fingerprint,
    mediaFingerprintVersion: contentIdentity.fingerprintVersion,
    mediaByteLength: contentIdentity.byteLength,
  };
}

/**
 * Determines whether media probing can be skipped safely because the URL itself
 * already identifies a non-HLS media resource. This avoids an unnecessary HEAD
 * request while preserving probing for opaque URLs whose content type is unknown.
 *
 * @example
 * Input: `https://cdn.example.com/video.mp4`
 * Output: true
 */
function shouldSkipMediaProbe(mediaUrl: string): boolean {
  if (looksLikeHlsUrl(mediaUrl)) return false;

  if (shouldPreferWorkerUploadForTelegram({ mediaType: "video" }, mediaUrl)) {
    return true;
  }

  const extension = getFileExtension(mediaUrl);
  return VIDEO_EXTENSIONS.has(extension) ||
    PHOTO_EXTENSIONS.has(extension) ||
    AUDIO_EXTENSIONS.has(extension);
}

export function resolveMaxMediaBytes(rawValue: string | undefined): number {
  const value = Number(rawValue);

  return clampMaxMediaBytes(Number.isFinite(value) ? value : undefined);
}

export function resolveConcurrency(rawValue: string | undefined): number {
  const value = Number(rawValue);

  if (!Number.isFinite(value)) {
    return 4;
  }

  return Math.min(6, Math.max(1, Math.floor(value)));
}

export function resolveHlsMaxMediaBytes(rawValue: string | undefined): number {
  const value = Number(rawValue);

  return clampHlsMaxMediaBytes(Number.isFinite(value) ? value : undefined);
}

export function inferTelegramMediaType(
  mediaUrl: string,
  contentType: string,
): MediaType {
  const type = getBaseContentType(contentType);

  if (type.startsWith("image/")) {
    return "photo";
  }

  if (type.startsWith("video/")) {
    return "video";
  }

  if (type.startsWith("audio/")) {
    return "audio";
  }

  const extension = getFileExtension(mediaUrl);

  if (PHOTO_EXTENSIONS.has(extension)) {
    return "photo";
  }

  if (VIDEO_EXTENSIONS.has(extension)) {
    return "video";
  }

  if (AUDIO_EXTENSIONS.has(extension)) {
    return "audio";
  }

  return "document";
}

/**
 * Forces Worker-owned uploads for videos whenever the configured size limit
 * permits it. This is intentionally provider-agnostic: the Worker must inspect
 * the actual container dimensions and send those dimensions to Telegram instead
 * of allowing a remote fetch to guess the media geometry.
 *
 * @example
 * shouldPreferWorkerUploadForTelegram({ mediaType: "video" }, "https://cdn.example/video.mp4");
 * // true
 */
export function shouldPreferWorkerUploadForTelegram(
  input: Pick<RelayInput, "mediaType">,
  _mediaUrl: string,
): boolean {
  return input.mediaType === "video";
}

function clampHlsMaxMediaBytes(value?: number): number {
  if (!Number.isFinite(value)) {
    return DEFAULT_HLS_MAX_MEDIA_BYTES;
  }

  return Math.min(
    HARD_HLS_MAX_MEDIA_BYTES,
    Math.max(1_000_000, Math.floor(value!)),
  );
}

function clampMaxMediaBytes(value?: number): number {
  if (!Number.isFinite(value)) {
    return DEFAULT_MAX_MEDIA_BYTES;
  }

  return Math.min(
    HARD_MAX_MEDIA_BYTES,
    Math.max(1_000_000, Math.floor(value!)),
  );
}

async function tryTwitterMediumQualityFallback(
  input: RelayInput,
  direct: ResolvedDirectFile,
  maximumBytes: number,
  signal?: AbortSignal,
  twirrlVersionToken?: string,
): Promise<PreparedMedia | null> {
  if (input.provider?.toLowerCase() !== "twitter") return null;
  if (direct.contentLength == null) return null;
  if (direct.contentLength <= MEDIUM_QUALITY_FALLBACK_TRIGGER_BYTES) return null;
  if (!input.sourceUrl) return null;
  if (signal?.aborted) return null;

  try {
    const medium = await resolveTwitterMediumMedia(
      input.sourceUrl,
      twirrlVersionToken,
    );

    if (!medium || medium.url === direct.url) return null;

    const downloadedMedium = await downloadDirectFile(
      medium.url,
      medium.mediaHeaders,
      maximumBytes,
      signal,
    );
    const bytes = downloadedMedium.bytes;

    const videoMetadata = parseVideoDimensions(
      bytes,
      inferContentTypeFromUrl(medium.url),
    );

    if (!videoMetadata) {
      throw new Error(
        "Twirrl medium-quality fallback did not expose valid video dimensions",
      );
    }

    return {
      type: "upload",
      bytes,
      filename: filenameFromUrl(medium.url),
      contentType: inferContentTypeFromUrl(medium.url),
      mediaType: "video",
      selectedBitrate: null,
      selectedResolution:
        medium.quality ||
        (medium.width && medium.height
          ? `${medium.width}x${medium.height}`
          : null),
      playlistDepth: 0,
      videoMetadata,
      sourceUrl: medium.url,
      hls: false,
      segmentCount: 1,
      encrypted: false,
      remuxed: false,
      mediaSha256: downloadedMedium.contentIdentity.sha256,
      mediaFingerprint: downloadedMedium.contentIdentity.fingerprint,
      mediaFingerprintVersion: downloadedMedium.contentIdentity.fingerprintVersion,
      mediaByteLength: downloadedMedium.contentIdentity.byteLength,
    };
  } catch {
    // A lower-quality retry is an optimization. If it cannot produce a safe
    // Worker-owned file, preserve the original error path instead of sending
    // an unverified remote video that could reintroduce aspect-ratio issues.
    return null;
  }
}

interface DownloadedDirectFile {
  bytes: Uint8Array;
  contentIdentity: ReturnType<MediaFingerprintAccumulator["digest"]>;
}

/**
 * Downloads a Worker-owned media body while hashing every received chunk in the
 * same pass. The bytes are still collected because the Telegram multipart path
 * requires a replayable Blob, but no second full-buffer hash pass is needed.
 *
 * @example
 * const downloaded = await downloadDirectFile(url, headers, 49_000_000);
 * console.log(downloaded.contentIdentity.sha256);
 */
async function downloadDirectFile(
  url: string,
  headers: HeadersInit,
  maximumBytes: number,
  signal?: AbortSignal,
): Promise<DownloadedDirectFile> {
  const response = await fetchPublic(url, {
    method: "GET",
    headers,
    signal,
  });

  if (!response.ok) {
    throw new Error(`HTTP ${response.status} while downloading direct media`);
  }

  const contentLength = Number(response.headers.get("content-length") || 0);
  if (contentLength > maximumBytes) {
    throw new Error(
      `Direct media exceeds the configured upload limit of ${maximumBytes} bytes`,
    );
  }

  const reader = response.body?.getReader();
  if (!reader) {
    const bytes = new Uint8Array(await response.arrayBuffer());
    if (bytes.byteLength > maximumBytes) {
      throw new Error(
        `Direct media exceeds the configured upload limit of ${maximumBytes} bytes`,
      );
    }
    const contentIdentity = new MediaFingerprintAccumulator().update(bytes).digest();
    return { bytes, contentIdentity };
  }

  const accumulator = new MediaFingerprintAccumulator();
  const chunks: Uint8Array[] = [];
  let totalBytes = 0;

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!value?.byteLength) continue;

      totalBytes += value.byteLength;
      if (totalBytes > maximumBytes) {
        throw new Error(
          `Direct media exceeds the configured upload limit of ${maximumBytes} bytes`,
        );
      }

      const chunk = new Uint8Array(value.byteLength);
      chunk.set(value);
      chunks.push(chunk);
      accumulator.update(chunk);
    }
  } finally {
    try { await reader.releaseLock(); } catch {}
  }

  const bytes = new Uint8Array(totalBytes);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }

  return {
    bytes,
    contentIdentity: accumulator.digest(),
  };
}

/**
 * A few X CDN edges reject HEAD but honor a one-byte range request. Use this
 * only for the Worker-owned Twitter video path so an unknown HEAD length does
 * not silently fall back to Telegram's remote re-fetch.
 */
async function probeContentLengthByRange(
  url: string,
  headers: HeadersInit,
  signal?: AbortSignal,
): Promise<number | null> {
  const rangeHeaders = new Headers(headers);
  rangeHeaders.set("Range", "bytes=0-0");

  try {
    const response = await fetchPublic(url, {
      method: "GET",
      headers: rangeHeaders,
      signal,
    });
    const contentRange = String(response.headers.get("content-range") || "");
    const total = Number(contentRange.match(/\/(\d+)\s*$/)?.[1] || 0);
    try { await response.body?.cancel(); } catch {}
    return Number.isFinite(total) && total > 0 ? total : null;
  } catch {
    return null;
  }
}

function inferContentTypeFromUrl(value: string): string {
  const extension = getFileExtension(value);

  if (PHOTO_EXTENSIONS.has(extension)) {
    if (extension === "jpg" || extension === "jpeg") return "image/jpeg";
    return `image/${extension}`;
  }

  if (VIDEO_EXTENSIONS.has(extension)) {
    return extension === "webm" ? "video/webm" : "video/mp4";
  }

  if (AUDIO_EXTENSIONS.has(extension)) {
    if (extension === "mp3") {
      return "audio/mpeg";
    }

    if (extension === "m4a") {
      return "audio/mp4";
    }

    return `audio/${extension}`;
  }

  return "application/octet-stream";
}

function filenameFromUrl(value: string): string {
  try {
    const url = new URL(value);
    const name = decodeURIComponent(url.pathname.split("/").pop() || "media");

    return sanitizeFilename(name || "media");
  } catch {
    return "media";
  }
}

function baseNameFromUrl(value: string): string {
  const filename = filenameFromUrl(value);

  return filename.replace(/\.[a-z0-9]{1,8}$/i, "") || "media";
}

function sanitizeFilename(value: string): string {
  return (
    String(value || "media")
      .replace(/[<>:"/\\|?*\u0000-\u001F]/g, "_")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 160) || "media"
  );
}
